import { useState } from "react";

type LeaderboardUser = {
  rank: number;
  initials: string;
  name: string;
  score: number;
  color: string;
};

export default function Index() {
  const [activeTab, setActiveTab] = useState<"stats" | "leaderboards">("leaderboards");
  const [isDarkMode, setIsDarkMode] = useState(true);

  // Sample data for the leaderboard
  const topThree: LeaderboardUser[] = [
    { rank: 2, initials: "SM", name: "Sarah M.", score: 2120, color: "#1A1A1A" },
    { rank: 1, initials: "AC", name: "Alex Chen", score: 2450, color: "#1A1A1A" },
    { rank: 3, initials: "JP", name: "Jordan P.", score: 2010, color: "#1A1A1A" },
  ];

  const otherUsers: LeaderboardUser[] = [
    { rank: 4, initials: "DK", name: "David K.", score: 1850, color: "#6366F1" },
    { rank: 5, initials: "EW", name: "Emma W.", score: 1720, color: "#14B8A6" },
    { rank: 6, initials: "MR", name: "Michael R.", score: 1680, color: "#F97316" },
    { rank: 7, initials: "LT", name: "Lisa T.", score: 1650, color: "#EF4444" },
    { rank: 8, initials: "JB", name: "James B.", score: 1620, color: "#10B981" },
  ];

  const userRank = 128;
  const userArticles = 840;

  return (
    <div className={isDarkMode ? "dark" : ""}>
      <div className="min-h-screen bg-dashboard-bg text-white">
        <div className="max-w-md mx-auto px-4 sm:px-6 py-11">
          {/* Header */}
          <header className="flex justify-between items-start mb-8">
            <div>
              <h1 className="text-2xl font-extrabold tracking-tight leading-8" style={{ letterSpacing: '-1.13px' }}>
                Reading Dashboard
              </h1>
              <p className="text-sm text-white/60 mt-3 leading-5" style={{ letterSpacing: '-0.15px' }}>
                Your personal performance and consistency tracker
              </p>
            </div>
            <button 
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="mt-2 w-5 h-5 flex items-center justify-center text-white/70 hover:text-white transition-colors"
              aria-label="Toggle theme"
            >
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9.99996 13.3334C11.8409 13.3334 13.3333 11.841 13.3333 10.0001C13.3333 8.15913 11.8409 6.66675 9.99996 6.66675C8.15901 6.66675 6.66663 8.15913 6.66663 10.0001C6.66663 11.841 8.15901 13.3334 9.99996 13.3334Z" stroke="currentColor" strokeWidth="1.66667" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M10 1.66675V3.33341" stroke="currentColor" strokeWidth="1.66667" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M10 16.6667V18.3334" stroke="currentColor" strokeWidth="1.66667" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M4.10828 4.1084L5.28328 5.2834" stroke="currentColor" strokeWidth="1.66667" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M14.7167 14.7166L15.8917 15.8916" stroke="currentColor" strokeWidth="1.66667" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M1.66663 10H3.33329" stroke="currentColor" strokeWidth="1.66667" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M16.6666 10H18.3333" stroke="currentColor" strokeWidth="1.66667" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M5.28328 14.7166L4.10828 15.8916" stroke="currentColor" strokeWidth="1.66667" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M15.8917 4.1084L14.7167 5.2834" stroke="currentColor" strokeWidth="1.66667" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
          </header>

          {/* Tabs */}
          <div className="flex items-center border-b border-white/5 mb-6">
            <button
              onClick={() => setActiveTab("stats")}
              className={`flex-1 py-2.5 text-sm font-medium leading-5 text-center transition-all ${
                activeTab === "stats"
                  ? "text-white border-b-2 border-dashboard-cyan"
                  : "text-white/40 border-b-2 border-transparent"
              }`}
              style={{ letterSpacing: '-0.15px' }}
            >
              Stats
            </button>
            <button
              onClick={() => setActiveTab("leaderboards")}
              className={`flex-1 py-2.5 text-sm font-medium leading-5 text-center transition-all ${
                activeTab === "leaderboards"
                  ? "text-white border-b-2 border-dashboard-cyan"
                  : "text-white/40 border-b-2 border-transparent"
              }`}
              style={{ letterSpacing: '-0.15px' }}
            >
              Leaderboards
            </button>
          </div>

          {/* Leaderboard Content */}
          {activeTab === "leaderboards" && (
            <div>
              {/* Leaderboard Header */}
              <div className="mb-6">
                <div className="flex items-start justify-between mb-6">
                  <div className="flex-1">
                    <h2 className="text-base font-bold leading-6 mb-2" style={{ letterSpacing: '-0.15px' }}>
                      Article reads leaderboard
                    </h2>
                    <p className="text-sm text-white/60 leading-5" style={{ letterSpacing: '-0.15px' }}>
                      Climb the rankings and earn<br />monthly awards and rewards.
                    </p>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5">
                      <span className="text-xs text-white/60" style={{ letterSpacing: '-0.15px' }}>
                        Leaderboard:
                      </span>
                      <span className="text-xs font-medium text-white" style={{ letterSpacing: '-0.15px' }}>
                        Global
                      </span>
                      <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M3 4.5L6 7.5L9 4.5" stroke="white" strokeOpacity="0.9" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </div>
                    <button className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-white/5 transition-colors">
                      <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M5 7.5L10 12.5L15 7.5" stroke="#00CCDD" strokeWidth="1.66667" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </button>
                  </div>
                </div>
              </div>

              {/* Podium - Top 3 */}
              <div className="flex items-end justify-center gap-4 mb-6 px-4">
                {/* 2nd Place */}
                <div className="flex flex-col items-center">
                  <div className="relative mb-3">
                    <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center border-2 border-white/10">
                      <span className="text-sm font-bold">{topThree[0].initials}</span>
                    </div>
                    <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-7 h-7 rounded-full bg-white/10 flex items-center justify-center text-xs font-bold">
                      #2
                    </div>
                  </div>
                  <p className="text-sm font-bold mb-0.5" style={{ letterSpacing: '-0.15px' }}>
                    {topThree[0].name}
                  </p>
                  <p className="text-sm text-dashboard-cyan font-medium" style={{ letterSpacing: '-0.15px' }}>
                    {topThree[0].score.toLocaleString()}
                  </p>
                </div>

                {/* 1st Place */}
                <div className="flex flex-col items-center -mt-6">
                  <div className="relative mb-3">
                    <div className="w-20 h-20 rounded-full bg-white/5 flex items-center justify-center border-2 border-dashboard-cyan">
                      <span className="text-lg font-bold">{topThree[1].initials}</span>
                    </div>
                    <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-gradient-to-br from-yellow-400 to-yellow-600 flex items-center justify-center text-xs font-bold text-white">
                      #1
                    </div>
                  </div>
                  <p className="text-sm font-bold mb-0.5" style={{ letterSpacing: '-0.15px' }}>
                    {topThree[1].name}
                  </p>
                  <p className="text-sm text-dashboard-cyan font-medium" style={{ letterSpacing: '-0.15px' }}>
                    {topThree[1].score.toLocaleString()}
                  </p>
                </div>

                {/* 3rd Place */}
                <div className="flex flex-col items-center">
                  <div className="relative mb-3">
                    <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center border-2 border-white/10">
                      <span className="text-sm font-bold">{topThree[2].initials}</span>
                    </div>
                    <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-7 h-7 rounded-full bg-white/10 flex items-center justify-center text-xs font-bold">
                      #3
                    </div>
                  </div>
                  <p className="text-sm font-bold mb-0.5" style={{ letterSpacing: '-0.15px' }}>
                    {topThree[2].name}
                  </p>
                  <p className="text-sm text-dashboard-cyan font-medium" style={{ letterSpacing: '-0.15px' }}>
                    {topThree[2].score.toLocaleString()}
                  </p>
                </div>
              </div>

              {/* Leaderboard List */}
              <div className="bg-dashboard-card rounded-2xl p-4 mb-6">
                <div className="space-y-3">
                  {otherUsers.map((user) => (
                    <div
                      key={user.rank}
                      className="flex items-center justify-between py-2"
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-sm text-white/40 font-medium w-6">
                          #{user.rank}
                        </span>
                        <div
                          className="w-10 h-10 rounded-full flex items-center justify-center text-white text-sm font-bold"
                          style={{ backgroundColor: user.color }}
                        >
                          {user.initials}
                        </div>
                        <span className="text-sm font-medium" style={{ letterSpacing: '-0.15px' }}>
                          {user.name}
                        </span>
                      </div>
                      <span className="text-sm font-medium" style={{ letterSpacing: '-0.15px' }}>
                        {user.score.toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* User Rank */}
              <div className="bg-dashboard-card rounded-2xl p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-white/80 mb-1" style={{ letterSpacing: '-0.15px' }}>
                      Your rank
                    </p>
                    <p className="text-xs text-white/50" style={{ letterSpacing: '-0.15px' }}>
                      {userArticles} articles read
                    </p>
                  </div>
                  <div className="text-3xl font-bold">
                    #{userRank}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Stats Content (Placeholder) */}
          {activeTab === "stats" && (
            <div className="bg-dashboard-card rounded-2xl p-8 text-center">
              <p className="text-white/60">Stats view coming soon...</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
