import { useState } from "react";
import { Sun } from "lucide-react";

export default function Index() {
  const [activeTab, setActiveTab] = useState<"stats" | "leaderboards">("stats");
  const [statusFilter, setStatusFilter] = useState<"empty" | "in-progress" | "completed" | "over-goal">("in-progress");
  const [isEditGoalsOpen, setIsEditGoalsOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#0B1215] text-white">
      <div className="max-w-[480px] mx-auto px-6 py-11">
        {/* Header */}
        <header className="mb-8">
          <div className="flex items-start justify-between mb-3">
            <div className="flex-1">
              <h1 className="text-2xl font-extrabold tracking-[-1.13px] leading-8 mb-1">
                Reading Dashboard
              </h1>
              <div className="w-6 h-0.5 bg-cyan rounded-full mb-3" />
              <p className="text-sm text-white/50 leading-5 tracking-[-0.15px]">
                Your personal performance and consistency tracker
              </p>
            </div>
            <button
              className="w-10 h-10 flex items-center justify-center rounded-full border border-white/10 bg-white/5 hover:bg-white/10 transition-colors mt-2"
              aria-label="Toggle theme"
            >
              <Sun className="w-5 h-5 text-white/70" />
            </button>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 p-1 border-b-2 border-transparent">
            <button
              onClick={() => setActiveTab("stats")}
              className={`flex-1 py-2 text-sm font-medium tracking-[-0.15px] transition-colors relative ${
                activeTab === "stats"
                  ? "text-white"
                  : "text-white/40"
              }`}
            >
              Stats
              {activeTab === "stats" && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan" />
              )}
            </button>
            <button
              onClick={() => setActiveTab("leaderboards")}
              className={`flex-1 py-2 text-sm font-medium tracking-[-0.15px] transition-colors relative ${
                activeTab === "leaderboards"
                  ? "text-white"
                  : "text-white/40"
              }`}
            >
              Leaderboards
              {activeTab === "leaderboards" && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan" />
              )}
            </button>
          </div>
        </header>

        {activeTab === "stats" ? (
          <StatsTab
            statusFilter={statusFilter}
            setStatusFilter={setStatusFilter}
            onEditGoals={() => setIsEditGoalsOpen(true)}
          />
        ) : (
          <LeaderboardsTab />
        )}

        {/* Edit Goals Modal */}
        {isEditGoalsOpen && (
          <EditGoalsModal onClose={() => setIsEditGoalsOpen(false)} />
        )}
      </div>
    </div>
  );
}

// Stats Tab Component
function StatsTab({
  statusFilter,
  setStatusFilter,
  onEditGoals,
}: {
  statusFilter: string;
  setStatusFilter: (filter: any) => void;
  onEditGoals: () => void;
}) {
  return (
    <div className="space-y-6">
      {/* Status Filters */}
      <div className="flex gap-2 overflow-x-auto pb-2 -mx-6 px-6 scrollbar-hide">
        {[
          { value: "empty", label: "Empty" },
          { value: "in-progress", label: "In progress" },
          { value: "completed", label: "Completed" },
          { value: "over-goal", label: "Over goal" },
        ].map((status) => (
          <button
            key={status.value}
            onClick={() => setStatusFilter(status.value)}
            className={`px-4 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
              statusFilter === status.value
                ? "bg-white/10 text-white border border-white/20"
                : "bg-white/5 text-white/50 border border-white/10 hover:bg-white/10"
            }`}
          >
            {status.label}
          </button>
        ))}
      </div>

      {/* Today's Goals */}
      <section className="bg-white/5 border border-white/10 rounded-2xl p-6 shadow-lg">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-base font-semibold tracking-[-0.15px]">Today's goals</h2>
          <span className="text-xs text-white/50">Fri, Jan 30</span>
        </div>

        <div className="space-y-6">
          {/* Reading Time Progress */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium tracking-[-0.15px]">Reading time</span>
              <span className="text-xs text-white/70">12 minutes remaining</span>
            </div>
            <div className="relative h-2 bg-white/10 rounded-full overflow-hidden">
              <div className="absolute inset-0 flex items-center">
                <div className="h-full bg-cyan rounded-full" style={{ width: "60%" }} />
                <div className="w-0.5 h-4 bg-white/70 -ml-px" />
              </div>
            </div>
          </div>

          {/* Articles Read Progress */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium tracking-[-0.15px]">Articles read</span>
              <span className="text-xs text-white/70">2 articles remaining</span>
            </div>
            <div className="relative h-2 bg-white/10 rounded-full overflow-hidden">
              <div className="absolute inset-0 flex items-center">
                <div className="h-full bg-cyan rounded-full" style={{ width: "40%" }} />
                <div className="w-0.5 h-4 bg-white/70 -ml-px" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Streak & Activity Cards */}
      <div className="grid grid-cols-3 gap-3">
        {/* Current Streak */}
        <div className="bg-white/5 border border-white/10 rounded-2xl p-4 shadow-lg">
          <div className="text-xs font-medium text-white/50 mb-2">Current streak</div>
          <div className="text-3xl font-bold tracking-[0.396px] leading-9">21</div>
          <div className="text-xs text-white/40 tracking-[-0.03px]">days</div>
        </div>

        {/* Max Streak */}
        <div className="bg-white/5 border border-white/10 rounded-2xl p-4 shadow-lg">
          <div className="text-xs font-medium text-white/50 mb-2">Max streak</div>
          <div className="text-3xl font-bold tracking-[0.396px] leading-9">47</div>
          <div className="text-xs text-white/40 tracking-[-0.03px]">days</div>
        </div>

        {/* Activity Log */}
        <div className="bg-white/5 border border-white/10 rounded-2xl p-4 shadow-lg">
          <div className="text-xs font-medium text-white/50 mb-4">Activity log</div>
          <div className="flex gap-1.5 flex-wrap">
            {Array.from({ length: 7 }).map((_, i) => (
              <div
                key={i}
                className={`w-2 h-2 rounded-full ${
                  i < 5 ? "bg-cyan" : "bg-white/20"
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Monthly Performance */}
      <section className="space-y-4">
        <div>
          <h3 className="text-base font-semibold tracking-[-0.15px] mb-1">
            Monthly performance
          </h3>
          <p className="text-xs text-white/50 tracking-[-0.03px]">
            Snapshot of your recent activity
          </p>
        </div>

        <div className="grid grid-cols-3 gap-3">
          {/* Articles Read */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-4 shadow-lg space-y-3">
            <div className="w-8 h-8 flex items-center justify-center rounded-full bg-cyan/20">
              <BookOpenIcon className="w-4 h-4 text-cyan" />
            </div>
            <div className="text-2xl font-bold tracking-[0.07px]">42</div>
            <div>
              <div className="text-[10px] font-medium text-white/50 tracking-[0.367px] mb-0.5">
                Articles read
              </div>
              <div className="text-[10px] font-medium text-cyan/90 tracking-[0.367px]">
                This month
              </div>
            </div>
          </div>

          {/* Articles Read Last Month */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-4 shadow-lg space-y-3">
            <div className="w-8 h-8 flex items-center justify-center rounded-full bg-white/10">
              <BookOpenIcon className="w-4 h-4 text-white/40" />
            </div>
            <div className="text-2xl font-bold text-white/60 tracking-[0.07px]">24</div>
            <div>
              <div className="text-[10px] font-medium text-white/30 tracking-[0.367px] mb-0.5">
                Articles read
              </div>
              <div className="text-[10px] font-medium text-white/40 tracking-[0.367px]">
                Last month
              </div>
            </div>
          </div>

          {/* Articles Shared */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-4 shadow-lg space-y-3">
            <div className="w-8 h-8 flex items-center justify-center rounded-full bg-cyan/20">
              <ShareIcon className="w-4 h-4 text-cyan" />
            </div>
            <div className="text-2xl font-bold tracking-[0.07px]">12</div>
            <div>
              <div className="text-[10px] font-medium text-white/50 tracking-[0.367px] mb-0.5">
                Articles shared
              </div>
              <div className="text-[10px] font-medium text-cyan/90 tracking-[0.367px]">
                This month
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {/* Reading Time */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-4 shadow-lg space-y-3">
            <div className="w-8 h-8 flex items-center justify-center rounded-full bg-cyan/20">
              <ClockIcon className="w-4 h-4 text-cyan" />
            </div>
            <div className="flex items-baseline gap-1">
              <div className="text-2xl font-bold tracking-[0.07px]">315</div>
              <div className="text-sm font-medium text-[#90A1B9]">minutes</div>
            </div>
            <div>
              <div className="text-[10px] font-medium text-white/50 tracking-[0.367px] mb-0.5">
                Reading time
              </div>
              <div className="text-[10px] font-medium text-cyan/90 tracking-[0.367px]">
                This month
              </div>
            </div>
          </div>

          {/* Edit Goals Button */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-4 shadow-lg flex flex-col items-center justify-center">
            <button
              onClick={onEditGoals}
              className="flex items-center gap-2 text-cyan hover:text-cyan/80 transition-colors"
            >
              <EditIcon className="w-3 h-3" />
              <span className="text-xs font-medium">Edit goals</span>
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}

// Leaderboards Tab Component
function LeaderboardsTab() {
  const leaderboardData = [
    { rank: 1, name: "Alex Chen", score: "###", isHighlighted: false },
    { rank: 2, name: "Sarah M.", score: "###", isHighlighted: false },
    { rank: 3, name: "You", score: "###", isHighlighted: true },
  ];

  return (
    <div className="space-y-6">
      {/* Status Filters */}
      <div className="flex gap-2 overflow-x-auto pb-2 -mx-6 px-6 scrollbar-hide">
        {["Empty", "In progress", "Completed", "Over goal"].map((status) => (
          <button
            key={status}
            className="px-4 py-1.5 rounded-full text-xs font-medium whitespace-nowrap bg-white/5 text-white/50 border border-white/10 hover:bg-white/10 transition-colors"
          >
            {status}
          </button>
        ))}
      </div>

      {/* Leaderboard Section */}
      <section className="bg-white/5 border border-white/10 rounded-2xl overflow-hidden shadow-lg">
        <div className="p-6 pb-4">
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-sm font-medium tracking-[-0.15px]">Articles</h2>
          </div>

          {/* Leaderboard List */}
          <div className="space-y-0">
            {leaderboardData.map((user, index) => (
              <div
                key={index}
                className={`flex items-center justify-between py-4 ${
                  index < leaderboardData.length - 1
                    ? "border-b border-white/5"
                    : ""
                } ${user.isHighlighted ? "bg-[#0F172B]/25" : ""}`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 flex items-center justify-center rounded-full bg-white/10">
                    <UserIcon className="w-4 h-4 text-white/70" />
                  </div>
                  <span className="text-sm font-medium tracking-[-0.15px]">
                    {user.name}
                  </span>
                </div>
                <span className="text-sm font-bold text-white/90 tracking-[-0.15px]">
                  {user.score}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* View Full Leaderboard */}
        <div className="relative py-6 bg-gradient-to-t from-[#0B1215] via-[#0B1215]/80 to-transparent">
          <button className="flex items-center justify-center gap-1.5 mx-auto text-cyan hover:text-cyan/80 transition-colors group">
            <span className="text-sm font-semibold tracking-[-0.15px]">
              View full leaderboard
            </span>
            <ChevronRightIcon className="w-3 h-3" />
          </button>
        </div>
      </section>
    </div>
  );
}

// Edit Goals Modal Component
function EditGoalsModal({ onClose }: { onClose: () => void }) {
  const [dailyArticles, setDailyArticles] = useState(3);
  const [dailyReadingTime, setDailyReadingTime] = useState(30);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative w-full max-w-[510px] bg-[#0B1215] rounded-2xl shadow-2xl overflow-hidden border border-white/10">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-6 border-b border-white/5 bg-[#0B1215]/80">
          <div>
            <h2 className="text-lg font-bold tracking-[-0.67px] leading-6">Edit Goals</h2>
            <p className="text-xs text-white/50 mt-1">Customize your reading habits</p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-white/10 transition-colors"
          >
            <CloseIcon className="w-5 h-5 text-white/70" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Daily Plan Summary */}
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="text-xs text-white/50 mb-1">Daily plan summary</div>
            <div className="text-2xl font-bold tracking-[0.396px]">
              {dailyArticles}{" "}
              <span className="text-sm font-normal text-white/70">
                articles / day
              </span>
            </div>
          </div>

          {/* Daily Articles Slider */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <label className="text-sm font-medium tracking-[-0.15px]">
                Daily articles
              </label>
              <span className="text-sm font-bold text-cyan">{dailyArticles}</span>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setDailyArticles(Math.max(1, dailyArticles - 1))}
                className="w-10 h-10 flex items-center justify-center rounded-full border border-white/10 bg-white/5 hover:bg-white/10 transition-colors"
              >
                <MinusIcon className="w-4 h-4" />
              </button>
              <div className="flex-1 h-2 bg-white/10 rounded-full relative">
                <div
                  className="absolute inset-y-0 left-0 bg-cyan rounded-full"
                  style={{ width: `${(dailyArticles / 10) * 100}%` }}
                />
              </div>
              <button
                onClick={() => setDailyArticles(Math.min(10, dailyArticles + 1))}
                className="w-10 h-10 flex items-center justify-center rounded-full border border-white/10 bg-white/5 hover:bg-white/10 transition-colors"
              >
                <PlusIcon className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Daily Reading Time */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <label className="text-sm font-medium tracking-[-0.15px]">
                Daily reading time
              </label>
              <span className="text-sm font-bold text-cyan">{dailyReadingTime} min</span>
            </div>
            <div className="h-2 bg-white/10 rounded-full relative">
              <div
                className="absolute inset-y-0 left-0 bg-cyan rounded-full"
                style={{ width: `${(dailyReadingTime / 90) * 100}%` }}
              />
            </div>
            <div className="flex items-center justify-between mt-2 text-[10px] text-white/40">
              <span>0m</span>
              <span>90m</span>
            </div>
          </div>

          {/* Time Zone */}
          <div>
            <label className="block text-sm font-medium tracking-[-0.15px] mb-2">
              Time zone
            </label>
            <p className="text-xs text-white/50 mb-3">
              Used to reset your daily goals and streaks.
            </p>
            <select className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-sm text-white appearance-none cursor-pointer hover:bg-white/10 transition-colors">
              <option>Eastern Time</option>
              <option>Central Time</option>
              <option>Mountain Time</option>
              <option>Pacific Time</option>
            </select>
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 pt-4 pb-6 border-t border-white/5 bg-[#0B1215]">
          <button
            onClick={onClose}
            className="w-full py-3.5 bg-cyan hover:bg-cyan/90 text-white font-bold text-sm tracking-[-0.15px] rounded-2xl shadow-lg shadow-cyan/20 transition-colors"
          >
            Save changes
          </button>
        </div>
      </div>
    </div>
  );
}

// Custom SVG Icons
function BookOpenIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none">
      <path
        d="M8 4.66675V14.0001"
        stroke="currentColor"
        strokeWidth="1.66667"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M2.00004 12C1.82323 12 1.65366 11.9298 1.52864 11.8047C1.40361 11.6797 1.33337 11.5101 1.33337 11.3333V2.66667C1.33337 2.48986 1.40361 2.32029 1.52864 2.19526C1.65366 2.07024 1.82323 2 2.00004 2H5.33337C6.04062 2 6.71889 2.28095 7.21899 2.78105C7.71909 3.28115 8.00004 3.95942 8.00004 4.66667C8.00004 3.95942 8.28099 3.28115 8.78109 2.78105C9.28119 2.28095 9.95946 2 10.6667 2H14C14.1769 2 14.3464 2.07024 14.4714 2.19526C14.5965 2.32029 14.6667 2.48986 14.6667 2.66667V11.3333C14.6667 11.5101 14.5965 11.6797 14.4714 11.8047C14.3464 11.9298 14.1769 12 14 12H10C9.46961 12 8.9609 12.2107 8.58583 12.5858C8.21075 12.9609 8.00004 13.4696 8.00004 14C8.00004 13.4696 7.78933 12.9609 7.41425 12.5858C7.03918 12.2107 6.53047 12 6.00004 12H2.00004Z"
        stroke="currentColor"
        strokeWidth="1.66667"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function ShareIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none">
      <g clipPath="url(#clip0_5_168)">
        <path
          d="M12 5.33325C13.1046 5.33325 14 4.43782 14 3.33325C14 2.22868 13.1046 1.33325 12 1.33325C10.8954 1.33325 10 2.22868 10 3.33325C10 4.43782 10.8954 5.33325 12 5.33325Z"
          stroke="currentColor"
          strokeWidth="1.66667"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M4 10C5.10457 10 6 9.10457 6 8C6 6.89543 5.10457 6 4 6C2.89543 6 2 6.89543 2 8C2 9.10457 2.89543 10 4 10Z"
          stroke="currentColor"
          strokeWidth="1.66667"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M12 14.6667C13.1046 14.6667 14 13.7713 14 12.6667C14 11.5622 13.1046 10.6667 12 10.6667C10.8954 10.6667 10 11.5622 10 12.6667C10 13.7713 10.8954 14.6667 12 14.6667Z"
          stroke="currentColor"
          strokeWidth="1.66667"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M5.72668 9.00659L10.28 11.6599"
          stroke="currentColor"
          strokeWidth="1.66667"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M10.2734 4.34009L5.72668 6.99342"
          stroke="currentColor"
          strokeWidth="1.66667"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </g>
      <defs>
        <clipPath id="clip0_5_168">
          <rect width="16" height="16" fill="white" />
        </clipPath>
      </defs>
    </svg>
  );
}

function ClockIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none">
      <g clipPath="url(#clip0_5_183)">
        <path
          d="M8.00004 14.6666C11.6819 14.6666 14.6667 11.6818 14.6667 7.99992C14.6667 4.31802 11.6819 1.33325 8.00004 1.33325C4.31814 1.33325 1.33337 4.31802 1.33337 7.99992C1.33337 11.6818 4.31814 14.6666 8.00004 14.6666Z"
          stroke="currentColor"
          strokeWidth="1.66667"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M8 4V8L10.6667 9.33333"
          stroke="currentColor"
          strokeWidth="1.66667"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </g>
      <defs>
        <clipPath id="clip0_5_183">
          <rect width="16" height="16" fill="white" />
        </clipPath>
      </defs>
    </svg>
  );
}

function EditIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 12 12" fill="none">
      <g clipPath="url(#clip0_5_200)">
        <path
          d="M10.587 3.40595C10.8513 3.14166 10.9999 2.78318 10.9999 2.40937C11 2.03557 10.8515 1.67705 10.5872 1.4127C10.3229 1.14834 9.96445 0.999803 9.59064 0.999756C9.21684 0.999709 8.85832 1.14816 8.59397 1.41245L1.92097 8.08695C1.80488 8.2027 1.71902 8.34521 1.67097 8.50195L1.01047 10.6779C0.997545 10.7212 0.996569 10.7671 1.00764 10.8109C1.01872 10.8546 1.04143 10.8946 1.07337 10.9264C1.1053 10.9583 1.14528 10.981 1.18905 10.992C1.23282 11.003 1.27875 11.0019 1.32197 10.9889L3.49847 10.3289C3.65505 10.2813 3.79755 10.196 3.91347 10.0804L10.587 3.40595Z"
          stroke="currentColor"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M7.5 2.5L9.5 4.5"
          stroke="currentColor"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </g>
      <defs>
        <clipPath id="clip0_5_200">
          <rect width="12" height="12" fill="white" />
        </clipPath>
      </defs>
    </svg>
  );
}

function UserIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none">
      <path
        d="M12.6667 14V12.6667C12.6667 11.9594 12.3858 11.2811 11.8857 10.781C11.3856 10.281 10.7073 10 10 10H6.00004C5.2928 10 4.61452 10.281 4.11442 10.781C3.61433 11.2811 3.33337 11.9594 3.33337 12.6667V14"
        stroke="currentColor"
        strokeWidth="1.33333"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M8.00004 7.33333C9.4728 7.33333 10.6667 6.13943 10.6667 4.66667C10.6667 3.19391 9.4728 2 8.00004 2C6.52728 2 5.33337 3.19391 5.33337 4.66667C5.33337 6.13943 6.52728 7.33333 8.00004 7.33333Z"
        stroke="currentColor"
        strokeWidth="1.33333"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function ChevronRightIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 12 12" fill="none">
      <path
        d="M6 12L10 8L6 4"
        stroke="currentColor"
        strokeWidth="1.66667"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function CloseIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 20 20" fill="none">
      <path
        d="M15 5L5 15"
        stroke="currentColor"
        strokeWidth="1.66667"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M5 5L15 15"
        stroke="currentColor"
        strokeWidth="1.66667"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function MinusIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none">
      <path
        d="M3.33337 8H12.6667"
        stroke="currentColor"
        strokeWidth="1.33333"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function PlusIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none">
      <path
        d="M3.33337 8H12.6667"
        stroke="currentColor"
        strokeWidth="1.33333"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M8 3.33325V12.6666"
        stroke="currentColor"
        strokeWidth="1.33333"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
