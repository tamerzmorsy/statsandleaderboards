import { DashboardHeader } from "@/components/DashboardHeader";
import { DashboardTabs } from "@/components/DashboardTabs";
import { TodaysGoals } from "@/components/TodaysGoals";
import { ConsistencyTracker } from "@/components/ConsistencyTracker";
import { MonthlyPerformance } from "@/components/MonthlyPerformance";
import { DailyGoals } from "@/components/DailyGoals";
import { LeaderboardPreview } from "@/components/LeaderboardPreview";

export default function Index() {
  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Background gradient blobs */}
      <div className="absolute -left-52 -top-48 w-[953px] h-[501px] rounded-full bg-cyan/5 blur-[100px] pointer-events-none" />
      <div className="absolute right-0 top-96 w-[1280px] h-[601px] rounded-full bg-[rgba(30,41,59,0.2)] blur-[100px] pointer-events-none" />
      <div className="absolute left-96 bottom-0 w-[1067px] h-[501px] rounded-full bg-cyan/5 blur-[120px] pointer-events-none" />
      
      {/* Main Content */}
      <div className="relative z-10 w-full max-w-md mx-auto px-4 sm:px-6 lg:px-8 py-11">
        <div className="flex flex-col gap-4">
          {/* Header */}
          <DashboardHeader />
          
          {/* Tabs */}
          <DashboardTabs />
          
          {/* Stats Content */}
          <div className="flex flex-col gap-6">
            {/* Today's Goals */}
            <TodaysGoals />
            
            {/* Consistency Tracker */}
            <ConsistencyTracker />
            
            {/* Monthly Performance */}
            <MonthlyPerformance />
            
            {/* Daily Goals */}
            <DailyGoals />
            
            {/* Leaderboard Preview */}
            <LeaderboardPreview />
          </div>
        </div>
      </div>
    </div>
  );
}
