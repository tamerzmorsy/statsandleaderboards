interface MetricCardProps {
  label: string;
  value: number;
  unit: string;
  subtitle?: string;
  opacity?: number;
}

function MetricCard({ label, value, unit, subtitle, opacity = 1 }: MetricCardProps) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 shadow-[0_10px_15px_-3px_rgba(0,0,0,0.1),0_4px_6px_-4px_rgba(0,0,0,0.1)] p-4 pb-0 flex flex-col justify-between">
      <p 
        className="text-xs font-medium leading-4 text-white/50 mb-3"
        style={{ opacity }}
      >
        {label}
      </p>
      <div className="mb-4">
        <div className="flex items-end">
          <span 
            className="text-[30px] font-bold leading-9 tracking-[0.396px]"
            style={{ 
              color: subtitle ? 'rgba(255, 255, 255, 0.9)' : '#FFFFFF'
            }}
          >
            {value}
          </span>
          <span className="text-base font-medium leading-6 tracking-tight text-white/50 ml-0 mb-[14px]">
            {unit}
          </span>
        </div>
        {subtitle && (
          <p className="text-[10px] leading-[15px] tracking-[0.117px] text-white/40 font-normal mt-1">
            {subtitle}
          </p>
        )}
      </div>
    </div>
  );
}

function ActivityLog() {
  const days = [
    { letter: 'M', active: false },
    { letter: 'T', active: true },
    { letter: 'W', active: false },
    { letter: 'T', active: true },
    { letter: 'F', active: true },
    { letter: 'S', active: true },
    { letter: 'S', active: true },
  ];

  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 shadow-[0_10px_15px_-3px_rgba(0,0,0,0.1),0_4px_6px_-4px_rgba(0,0,0,0.1)] p-4 pb-0 flex flex-col justify-between">
      <p className="text-xs font-medium leading-4 text-white/50 mb-3">
        Activity log
      </p>
      <div className="flex justify-between items-end pb-4">
        {days.map((day, index) => (
          <div key={index} className="flex flex-col items-center gap-1.5">
            {day.active ? (
              <div className="w-2 h-2 rounded-full bg-cyan shadow-[0_0_8px_0_rgba(0,204,221,0.4)]" />
            ) : (
              <div className="w-2 h-2 rounded-full border border-white/20" />
            )}
            <span className="text-[9px] leading-[13.5px] tracking-[0.167px] text-white/30 font-medium">
              {day.letter}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function ConsistencyTracker() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
      <MetricCard 
        label="Current streak"
        value={21}
        unit="days"
      />
      <MetricCard 
        label="Max streak"
        value={47}
        unit="days"
        subtitle="Personal best"
        opacity={0.8}
      />
      <ActivityLog />
    </div>
  );
}
