import { Edit3 } from "lucide-react";

interface GoalItemProps {
  label: string;
  target: string;
  value: string;
}

function GoalItem({ label, target, value }: GoalItemProps) {
  return (
    <div className="flex justify-between items-center">
      <div className="flex flex-col gap-0.5">
        <p className="text-sm font-medium leading-5 tracking-tight text-white">
          {label}
        </p>
        <p className="text-xs font-normal leading-4 text-white/50">
          {target}
        </p>
      </div>
      <p className="text-sm font-bold leading-5 tracking-tight text-white/90">
        {value}
      </p>
    </div>
  );
}

export function DailyGoals() {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 shadow-[0_10px_15px_-3px_rgba(0,0,0,0.1),0_4px_6px_-4px_rgba(0,0,0,0.1)] p-4 pb-1 flex flex-col gap-5">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-semibold leading-7 tracking-tight text-white">
          Daily goals
        </h2>
        <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-cyan/30 hover:border-cyan/50 transition-colors">
          <Edit3 className="w-3 h-3 text-cyan" strokeWidth={1.5} />
          <span className="text-xs font-medium leading-4 text-cyan">
            Edit goals
          </span>
        </button>
      </div>
      
      {/* Goals List */}
      <div className="flex flex-col gap-4">
        <GoalItem 
          label="Articles"
          target="Target: 4 per day"
          value="4 / day"
        />
        <div className="h-px bg-white/5" />
        <GoalItem 
          label="Reading time"
          target="Target: 30 minutes per day"
          value="30 min / day"
        />
      </div>
    </div>
  );
}
