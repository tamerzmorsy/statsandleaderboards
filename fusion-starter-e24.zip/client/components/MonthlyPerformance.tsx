import { BookOpen, Share2, Clock } from "lucide-react";

interface MetricProps {
  icon: React.ReactNode;
  value: string;
  label: string;
  period: string;
  highlighted?: boolean;
  dimmed?: boolean;
}

function Metric({ icon, value, label, period, highlighted, dimmed }: MetricProps) {
  return (
    <div className={`flex flex-col items-center justify-center gap-3 py-6 ${dimmed ? 'bg-white/5' : ''}`}>
      <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center pt-2">
        {icon}
      </div>
      <div className="flex items-baseline gap-0">
        <span className={`text-2xl font-bold leading-8 tracking-[0.07px] ${dimmed ? 'text-white/60' : 'text-white'}`}>
          {value}
        </span>
      </div>
      <div className="flex flex-col items-center gap-0.5">
        <p className={`text-[10px] leading-[15px] tracking-[0.367px] font-medium text-center ${dimmed ? 'text-white/30' : 'text-white/50'}`}>
          {label}
        </p>
        <p className={`text-[10px] leading-[15px] tracking-[0.117px] font-medium text-center ${highlighted ? 'text-cyan/90' : dimmed ? 'text-white/40' : 'text-cyan/90'}`}>
          {period}
        </p>
      </div>
    </div>
  );
}

export function MonthlyPerformance() {
  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-3 pl-1">
        <div className="w-1 h-8 rounded-full bg-cyan/80" />
        <div className="flex flex-col">
          <h2 className="text-lg font-semibold leading-[22.5px] tracking-tight text-white">
            Monthly performance
          </h2>
          <p className="text-xs font-medium leading-4 text-white/60">
            Snapshot of your recent activity
          </p>
        </div>
      </div>

      <div className="rounded-2xl border border-white/10 bg-white/5 shadow-[0_10px_15px_-3px_rgba(0,0,0,0.1),0_4px_6px_-4px_rgba(0,0,0,0.1)] overflow-hidden">
        <div className="grid grid-cols-2">
          {/* Articles read this month */}
          <div className="border-r border-b border-white/10">
            <Metric 
              icon={<BookOpen className="w-4 h-4 text-cyan" strokeWidth={1.67} />}
              value="42"
              label="Articles read"
              period="This month"
              highlighted
            />
          </div>
          
          {/* Articles read last month */}
          <div className="border-b border-white/10 bg-white/5">
            <Metric 
              icon={<BookOpen className="w-4 h-4 text-white/40" strokeWidth={1.67} />}
              value="24"
              label="Articles read"
              period="Last month"
              dimmed
            />
          </div>
          
          {/* Articles shared */}
          <div className="border-r border-white/10">
            <Metric 
              icon={<Share2 className="w-4 h-4 text-cyan" strokeWidth={1.67} />}
              value="12"
              label="Articles shared"
              period="This month"
              highlighted
            />
          </div>
          
          {/* Reading time */}
          <div>
            <Metric 
              icon={<Clock className="w-4 h-4 text-cyan" strokeWidth={1.67} />}
              value="315"
              label="Reading time"
              period="This month"
              highlighted
            />
          </div>
        </div>
      </div>
    </div>
  );
}

// Custom minutes display component
function MinutesMetric() {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-6">
      <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center pt-2">
        <Clock className="w-4 h-4 text-cyan" strokeWidth={1.67} />
      </div>
      <div className="flex items-baseline gap-0">
        <span className="text-2xl font-bold leading-8 tracking-[0.07px] text-white">315</span>
        <span className="text-sm font-medium leading-5 tracking-tight text-[#90A1B9] ml-1.5 mb-[12px]">minutes</span>
      </div>
      <div className="flex flex-col items-center gap-0.5">
        <p className="text-[10px] leading-[15px] tracking-[0.367px] font-medium text-white/50 text-center">
          Reading time
        </p>
        <p className="text-[10px] leading-[15px] tracking-[0.117px] font-medium text-cyan/90 text-center">
          This month
        </p>
      </div>
    </div>
  );
}
