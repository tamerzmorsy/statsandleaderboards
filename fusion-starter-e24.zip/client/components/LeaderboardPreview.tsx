import { User, ChevronRight } from "lucide-react";

interface LeaderboardEntryProps {
  rank: number;
  name: string;
  score: string;
  isCurrentUser?: boolean;
  blur?: number;
  opacity?: number;
}

function LeaderboardEntry({ rank, name, score, isCurrentUser, blur = 0, opacity = 1 }: LeaderboardEntryProps) {
  const getRankStyle = () => {
    if (rank === 1) return "bg-gold/20 text-gold";
    if (rank === 2) return "bg-silver/20 text-silver";
    if (rank === 3) return "bg-bronze/20 text-bronze";
    return "bg-white/20 text-white/70";
  };

  return (
    <div 
      className={`flex justify-between items-center px-4 h-14 border-b border-white/5 ${rank === 1 ? 'bg-white/5' : ''} ${rank === 3 ? 'bg-[rgba(15,23,43,0.15)]' : ''}`}
      style={{ 
        filter: blur > 0 ? `blur(${blur}px)` : 'none',
        opacity 
      }}
    >
      <div className="flex items-center gap-3">
        <div className={`w-6 h-6 rounded-full flex items-center justify-center ${getRankStyle()}`}>
          <span className="text-xs font-bold leading-4">{rank}</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
            <User className="w-4 h-4 text-white/70" strokeWidth={1.33} />
          </div>
          <span className="text-sm font-medium leading-5 tracking-tight text-white">
            {name}
          </span>
        </div>
      </div>
      <span className="text-sm font-bold leading-5 tracking-tight text-white/90">
        {score}
      </span>
    </div>
  );
}

export function LeaderboardPreview() {
  return (
    <div className="rounded-[20px] border border-white/10 bg-white/5 shadow-[0_10px_15px_-3px_rgba(0,0,0,0.1),0_4px_6px_-4px_rgba(0,0,0,0.1)] overflow-hidden">
      {/* Header */}
      <div className="px-4 pt-4 pb-3 border-b border-white/5">
        <h2 className="text-lg font-semibold leading-7 tracking-tight text-white">
          Leaderboard preview
        </h2>
      </div>
      
      {/* Leaderboard entries */}
      <div className="relative">
        <LeaderboardEntry rank={1} name="Alex Chen" score="###" />
        <LeaderboardEntry rank={2} name="Sarah M." score="###" opacity={0.75} />
        <LeaderboardEntry rank={3} name="You" score="###" opacity={0.5} blur={1.5} />
        
        {/* Gradient overlay */}
        <div className="absolute inset-0 top-14 bg-gradient-to-b from-transparent via-[rgba(15,23,43,0.4)] to-[#0B1215] pointer-events-none" />
        
        {/* View full leaderboard button */}
        <div className="relative pt-10 pb-4 flex justify-center">
          {/* Glow effect */}
          <div className="absolute top-14 left-1/2 -translate-x-1/2 w-48 h-8 rounded-full bg-cyan/20 blur-[24px]" />
          
          <button className="relative flex items-center gap-1.5 text-sm font-semibold leading-5 tracking-tight text-cyan hover:text-cyan/80 transition-colors group">
            <span>View full leaderboard</span>
            <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" strokeWidth={1.67} />
          </button>
        </div>
      </div>
    </div>
  );
}
