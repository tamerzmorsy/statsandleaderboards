import { useState } from "react";

export function DashboardTabs() {
  const [activeTab, setActiveTab] = useState<"stats" | "leaderboards">("stats");

  return (
    <div className="flex items-start gap-0 p-1 pt-0 mb-6">
      <button
        onClick={() => setActiveTab("stats")}
        className={`flex-1 py-0.5 pb-2.5 text-center text-sm font-medium leading-5 tracking-tight transition-all ${
          activeTab === "stats"
            ? "text-white border-b-2 border-cyan"
            : "text-white/40 border-b-2 border-transparent hover:text-white/60"
        }`}
      >
        Stats
      </button>
      <button
        onClick={() => setActiveTab("leaderboards")}
        className={`flex-1 py-0.5 pb-2.5 text-center text-sm font-medium leading-5 tracking-tight transition-all ${
          activeTab === "leaderboards"
            ? "text-white border-b-2 border-cyan"
            : "text-white/40 border-b-2 border-transparent hover:text-white/60"
        }`}
      >
        Leaderboards
      </button>
    </div>
  );
}
