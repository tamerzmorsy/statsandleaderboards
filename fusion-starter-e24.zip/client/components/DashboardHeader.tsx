import { Sun } from "lucide-react";

export function DashboardHeader() {
  return (
    <div className="flex justify-between items-start pt-2 mb-4">
      <div className="flex flex-col gap-3">
        <div className="flex flex-col gap-1">
          <h1 className="text-2xl font-extrabold leading-8 tracking-tighter text-white">
            Reading Dashboard
          </h1>
          <div className="w-6 h-0.5 rounded-full bg-cyan" />
        </div>
        <p className="text-sm font-medium leading-5 tracking-tight text-white/70">
          Your personal performance and consistency tracker
        </p>
      </div>
      <button
        className="w-9 h-9 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors"
        aria-label="Toggle theme"
      >
        <Sun className="w-5 h-5 text-white/70" />
      </button>
    </div>
  );
}
