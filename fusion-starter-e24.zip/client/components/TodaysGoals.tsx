import { Zap } from "lucide-react";

interface GoalMetricProps {
  label: string;
  progress: number;
}

function GoalMetric({ label, progress }: GoalMetricProps) {
  return (
    <div className="flex flex-col gap-2">
      <div className="flex justify-between items-start">
        <p className="text-sm font-semibold leading-5 tracking-tight text-white">
          {label}
        </p>
        <div className="flex flex-col items-end gap-0.5">
          <div className="flex items-center gap-1.5">
            <div className="relative w-3.5 h-3.5">
              <div className="absolute inset-0 rounded-full bg-cyan/20 blur-[8px] opacity-[0.99]" />
              <Zap className="absolute inset-0 w-3.5 h-3.5 text-cyan fill-cyan opacity-[0.99]" strokeWidth={1.75} />
            </div>
            <span className="text-xs font-bold leading-4 text-white">
              You're on a roll
            </span>
          </div>
          <p className="text-[10px] leading-[12.5px] tracking-[0.117px] text-cyan font-medium">
            Extra reading logged today
          </p>
        </div>
      </div>
      
      {/* Progress Bar */}
      <div className="relative h-2">
        {/* Glow effect */}
        <div className="absolute -inset-x-0.5 -inset-y-1 rounded-full bg-cyan/40 blur-[12px]" />
        
        {/* Background track */}
        <div className="absolute inset-0 rounded-full bg-white/10 overflow-hidden">
          {/* Filled progress */}
          <div className="h-full rounded-full overflow-hidden" style={{ width: '100%' }}>
            <div className="h-full bg-gradient-to-b from-cyan to-cyan-bright" />
            {/* Shimmer effect */}
            <div 
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent"
              style={{ left: '93px', width: '382px' }}
            />
          </div>
        </div>
        
        {/* Outer glow */}
        <div className="absolute inset-0 rounded-full shadow-[0_0_15px_0_rgba(0,204,221,0.6)]" />
        
        {/* Goal marker */}
        <div 
          className="absolute w-0.5 h-3.5 -top-0.5 rounded-full bg-cyan opacity-80"
          style={{ left: `${progress * 0.87}%` }}
        />
      </div>
    </div>
  );
}

export function TodaysGoals() {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 shadow-[0_10px_15px_-3px_rgba(0,0,0,0.1),0_4px_6px_-4px_rgba(0,0,0,0.1)] p-4 flex flex-col gap-4">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-semibold leading-7 tracking-tight text-white">
          Today's goals
        </h2>
        <span className="text-xs font-medium leading-4 text-white/40">
          Mon, Jan 26
        </span>
      </div>
      
      {/* Goal Metrics */}
      <div className="flex flex-col gap-6">
        <GoalMetric label="Reading time" progress={100} />
        <GoalMetric label="Articles read" progress={100} />
      </div>
    </div>
  );
}
